# checkoutservice

Run the following command to restore dependencies to `vendor/` directory:

    dep ensure --vendor-only
